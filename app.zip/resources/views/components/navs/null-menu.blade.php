<ul class="nav nav-pills flex-column mt-3 gap-3">
  <li class="nav-item">
    <a class="nav-link dash-link" href="/overview/">
      <i class="fa fa-dashboard"></i> Dashboard
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link dash-link">
      <i class="fa fa-exclamation-triangle text-danger"></i> Nothing to load...
    </a>
  </li>

</ul>