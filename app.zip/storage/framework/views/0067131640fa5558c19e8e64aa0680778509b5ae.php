<div class="container-fluid page-footer">
	<div class="row justify-content-center justify-content-sm-between ">
		<div class="col-12 col-sm-6 py-4">
			<p>
				Copyright @ <b>2022</b> <a href="https://zeteohealthlimited.com" target="_blank" class="footer-link">Zeteo Health Limited</a>
			</p>
		</div>

		<div class="col-12 col-sm-6 py-4">
			<div class="nav flex-row justify-content-center justify-content-sm-end">
				<a href="/" class="nav-link">About</a>
				<a href="" class="nav-link">Terms</a>
				<a href="" class="nav-link">Privacy</a>
			</div>
		</div>
	</div>
</div><?php /**PATH /home/zeteohea/account-manager/resources/views/components/navs/users-copy.blade.php ENDPATH**/ ?>