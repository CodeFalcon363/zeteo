    <h4 class="text-center ">
        Zeteo Health Limited
    </h4>
<?php /**PATH /home/zeteohea/account-manager/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>