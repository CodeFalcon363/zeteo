<div class="py-3">
    <hr />
</div>
<?php /**PATH /home/zeteohea/account-manager/resources/views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>