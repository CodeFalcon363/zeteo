<div class="container">
    <div class="row justify-content-center my-sm-5">
        <div class="col-sm-12 col-md-8 col-lg-5 my-sm-4">

            <div class="card shadow px-1 mx-1 mx-sm-3 my-2 my-sm-0">
                <div class="card-header bg-white">
                     <?php echo e($logo); ?>

                </div>
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH /home/zeteohea/account-manager/resources/views/vendor/jetstream/components/authentication-card.blade.php ENDPATH**/ ?>